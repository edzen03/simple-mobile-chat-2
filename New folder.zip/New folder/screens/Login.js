import React, { useState } from "react";
import { StyleSheet, Text, View, Image, SafeAreaView, TouchableOpacity, StatusBar, Alert } from "react-native";
//import { signInWithEmailAndPassword } from "firebase/auth";
//import { auth } from "../cofig/firebase";
const backImage = require("../assets/backImage.png");
import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';

export default function Login({ navigation }) {
  const [accessToken, setAccessToken] = React.useState();
  const [userInfo, setUserInfo] = React.useState();
  const [message, setMessage] = React.useState();

  const [request, response, promptAsync] = Google.useAuthRequest({
    androidClientId: "697402007992-o03utb9q8ctl0l25vaddgkgprc1beshm.apps.googleusercontent.com",
    expoClientId: "697402007992-gkpcnofb8gt25mj17ecio9gbkt67rll9.apps.googleusercontent.com"
  });

  const onHandleLogin = () => {
    if (userInfo) {
      return (
        <View style={styles.userInfo}>
          <Image source={{uri: userInfo.picture}} style={styles.profilePic} />
          <Text>Welcome {userInfo.name}</Text>
          <Text>{userInfo.email}</Text>
        </View>
      );
    }
  };

  React.useEffect(() => {
    setMessage(JSON.stringify(response));
    if (response?.type === "success") {
      setAccessToken(response.authentication.accessToken);
    }
  }, [response]);

  async function getUserData() {
    let userInfoResponse = await fetch("https://www.googleapis.com/userinfo/v2/me",{
        headers: { Authorization: `Bearer ${accessToken}` },
    });
    userInfoResponse.json().then((data) => {
      setUserInfo(data);
    });
  }
  
  function showUserInfo() {
    if (userInfo) {
      return (
        <View style={styles.userInfo}>
          <Image source={{uri: userInfo.picture}} style={styles.profilePic} />
          <Text>Welcome {userInfo.name}</Text>
          <Text>{userInfo.email}</Text>
        </View>
      );
    }
  }

  return (
    <View style={styles.container}>
      <Image source={backImage} style={styles.backImage} />
      <View style={styles.whiteSheet} />
        <SafeAreaView style={styles.form}>
          <Text style={styles.title}>Welcome!</Text>          
          <TouchableOpacity style={styles.button} onPress={onHandleLogin}>
            <Text style={{fontWeight: 'bold', color: '#fff', fontSize: 18}}> Sign In with Google</Text>
          </TouchableOpacity>
        </SafeAreaView>
      <StatusBar barStyle="light-content" />
    </View>
  );
}
  const styles = StyleSheet.create({
    backImage: {
      width: "100%",
      height: 340,
      position: "absolute",
      top: 0,
      resizeMode: 'cover',
    },
    button: {
      backgroundColor: '#f57c00',
      height: 58,
      borderRadius: 10,
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 40,
    },
    container: {
      flex: 1,
      backgroundColor: "#fff",
    },
    form: {
      flex: 1,
      justifyContent: 'center',
      marginHorizontal: 30,
    },
    profilePic: {
      width: 50,
      height: 50
    },
    title: {
      fontSize: 36,
      fontWeight: 'bold',
      color: "orange",
      alignSelf: "center",
      paddingBottom: 24,
    },
    userInfo: {
      alignItems: 'center',
      justifyContent: 'center',
    },
    whiteSheet: {
      width: '100%',
      height: '75%',
      position: "absolute",
      bottom: 0,
      backgroundColor: '#fff',
      borderTopLeftRadius: 60,
    }
});